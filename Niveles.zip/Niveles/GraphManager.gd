extends Node
class_name GraphManagerImpl

const EPS: float = 1e-6
const INF: float = 1e18

var nodes: Array = []
var adj: Dictionary = {}
var capacity: Dictionary = {}
var initial_capacity: Dictionary = {}
var edge_visuals: Dictionary = {}

var last_max_flow: float = 0.0
var last_flows_map: Dictionary = {}

var files: Dictionary = {}
var global_counter: int = 5
var send_log: Array = []
var validation_log: Array = []
var game_over: bool = false

var _ts_seq: int = 0

@export var self_test: bool = false
@export var auto_load_data: bool = true

func _ready() -> void:
	# Rutas candidatas
	var files_candidates: Array = ["res://data/files.json", "res://files.json"]
	var graph_candidates: Array = ["res://data/graph.json", "res://graph.json"]

	var files_path: String = ""
	for p in files_candidates:
		if FileAccess.file_exists(p):
			files_path = p
			break

	var graph_path: String = ""
	for p in graph_candidates:
		if FileAccess.file_exists(p):
			graph_path = p
			break

	if files_path != "":
		var load_result: Dictionary = load_files_from_json(files_path)
		print("[GraphManager] load_files_from_json ->", load_result)
	else:
		print("[GraphManager] files.json no encontrado en candidatos - cargando datos por defecto en memoria")
		_load_default_files_in_memory()

	if graph_path != "":
		var load_graph_result: Dictionary = load_graph_from_file(graph_path)
		print("[GraphManager] load_graph_from_file ->", load_graph_result)
	else:
		print("[GraphManager] graph.json no encontrado en candidatos - cargando grafo por defecto en memoria")
		_load_default_graph_in_memory()

	validate_all_files()
	print("[GraphManager] Files cargados:", list_files())
	show_graph()

# --------------------
# Datos por defecto en memoria
# --------------------
func _load_default_files_in_memory() -> void:
	var defaults: Array = [
		{"id":"file001","user":"alice","code":"ABC","weight":5.0,"current_node":"file001"},
		{"id":"file002","user":"bob","code":"XYZ","weight":3.0,"current_node":"file002"},
		{"id":"file003","user":"carol","code":"AAA","weight":4.0,"current_node":"file003"},
		{"id":"file004","user":"dave","code":"BBB","weight":2.0,"current_node":"file004"},
		{"id":"file005","user":"erin","code":"CCC","weight":6.0,"current_node":"file005"},
		{"id":"file006","user":"frank","code":"DDD","weight":1.0,"current_node":"file006"}
	]
	for e in defaults:
		if typeof(e) == TYPE_DICTIONARY:
			var fid: String = str(e.get("id",""))
			if fid == "":
				continue
			var user: String = str(e.get("user",""))
			var code: String = str(e.get("code",""))
			var weight: float = float(e.get("weight", 1.0))
			var node: String = str(e.get("current_node", fid))
			if not files.has(fid):
				add_file(fid, user, code, weight, node)
			else:
				var exist: Dictionary = files[fid]
				exist["user"] = user
				exist["code"] = code
				exist["weight"] = weight
				exist["current_node"] = node
				files[fid] = exist
			_ensure_node(node)

func _load_default_graph_in_memory() -> void:
	var ids: Array = []
	for k in files.keys():
		ids.append(str(k))
	if ids.size() == 0:
		_ensure_node("file001")
		_ensure_node("file002")
		_ensure_node("file003")
		_ensure_node("file004")
		_ensure_node("file005")
		_ensure_node("file006")
		ids = ["file001","file002","file003","file004","file005","file006"]

	for i in range(ids.size() - 1):
		var u: String = str(ids[i])
		var v: String = str(ids[i + 1])
		var cap: float = 2.0
		add_edge(u, v, cap)
	if ids.size() >= 3:
		add_edge(str(ids[ids.size() - 1]), str(ids[0]), 1.0)

# --------------------
# Utilitarios básicos de grafo
# --------------------
func _ensure_node(id: String) -> void:
	if not nodes.has(id):
		nodes.append(id)
		adj[id] = []
		capacity[id] = {}
		initial_capacity[id] = {}

func add_edge(u: String, v: String, cap: float, visual_node: Object = null) -> void:
	_ensure_node(u)
	_ensure_node(v)
	var list_uv: Array = adj[u]
	if not list_uv.has(v):
		list_uv.append(v)
		adj[u] = list_uv
	var list_vu: Array = adj[v]
	if not list_vu.has(u):
		list_vu.append(u)
		adj[v] = list_vu
	capacity[u][v] = float(cap)
	if not capacity[v].has(u):
		capacity[v][u] = 0.0
	initial_capacity[u][v] = float(cap)
	if not initial_capacity[v].has(u):
		initial_capacity[v][u] = 0.0
	if visual_node != null:
		edge_visuals[u + "|" + v] = visual_node

func get_capacity(u: String, v: String) -> float:
	if capacity.has(u) and capacity[u].has(v):
		return float(capacity[u].get(v, 0.0))
	return 0.0

func set_capacity(u: String, v: String, new_cap: float) -> void:
	_ensure_node(u)
	_ensure_node(v)
	capacity[u][v] = float(new_cap)
	initial_capacity[u][v] = float(new_cap)
	var key: String = u + "|" + v
	if edge_visuals.has(key):
		var vis: Object = edge_visuals[key]
		if vis != null and vis.has_method("set_capacity"):
			vis.set_capacity(new_cap)

# --------------------
# BFS residual para Edmonds-Karp
# --------------------
func _bfs_parent(residual: Dictionary, source: String, sink: String) -> Dictionary:
	var visited: Dictionary = {}
	var parent: Dictionary = {}
	for id in nodes:
		visited[id] = false
		parent[id] = null
	var q: Array = []
	q.push_back(source)
	visited[source] = true
	parent[source] = ""
	while q.size() > 0:
		var u: String = q.pop_front()
		var neighbors: Array = adj.get(u, [])
		for v_item in neighbors:
			var v: String = String(v_item)
			if not visited.get(v, false):
				var res_cap: float = float(residual[u].get(v, 0.0))
				if res_cap > EPS:
					parent[v] = u
					visited[v] = true
					if v == sink:
						return parent
					q.push_back(v)
	if parent.get(sink, null) == null:
		return {}
	return parent

# --------------------
# Edmonds-Karp
# --------------------
func compute_max_flow(source: String, sink: String) -> Dictionary:
	if not nodes.has(source) or not nodes.has(sink):
		return {"flow": 0.0, "flows": {}}

	var residual: Dictionary = {}
	for u_item in nodes:
		var u: String = String(u_item)
		residual[u] = {}
		var keys: Array = []
		if capacity.has(u):
			keys = capacity[u].keys()
		for v_key in keys:
			var vstr: String = String(v_key)
			residual[u][vstr] = float(capacity[u].get(v_key, 0.0))

	var max_flow: float = 0.0
	while true:
		var parent: Dictionary = _bfs_parent(residual, source, sink)
		if parent.size() == 0:
			break
		var path_flow: float = INF
		var v: String = sink
		while v != source:
			var u: String = parent.get(v, null)
			if u == null:
				path_flow = 0.0
				break
			var avail: float = float(residual[u].get(v, 0.0))
			if avail < path_flow:
				path_flow = avail
			v = u
		if path_flow <= EPS:
			break
		v = sink
		while v != source:
			var u2: String = parent.get(v, null)
			if u2 == null:
				break
			residual[u2][v] = float(residual[u2].get(v, 0.0)) - path_flow
			if not residual[v].has(u2):
				residual[v][u2] = 0.0
			residual[v][u2] = float(residual[v].get(u2, 0.0)) + path_flow
			v = u2
		max_flow += path_flow

	var flows_map: Dictionary = {}
	for u_item in nodes:
		var u: String = String(u_item)
		var keys2: Array = []
		if initial_capacity.has(u):
			keys2 = initial_capacity[u].keys()
		for v_key in keys2:
			var v: String = String(v_key)
			var capval: float = float(initial_capacity[u].get(v, 0.0))
			if capval > 0.0:
				var residual_forward: float = float(residual[u].get(v, 0.0))
				var fval: float = capval - residual_forward
				if fval < 0.0 and fval > -EPS:
					fval = 0.0
				flows_map[u + "|" + v] = fval
				var vis_key: String = u + "|" + v
				if edge_visuals.has(vis_key):
					var vis: Object = edge_visuals[vis_key]
					if vis != null:
						if vis.has_method("set_capacity"):
							vis.set_capacity(capval)
						if vis.has_method("set_flow"):
							vis.set_flow(fval)

	last_max_flow = max_flow
	last_flows_map = flows_map.duplicate(true)

	return {"flow": max_flow, "flows": flows_map}

# --------------------
# Finder de ruta considerando capacidades actuales
# --------------------
func _find_path_with_capacity(source: String, sink: String, need: float) -> Array:
	if not nodes.has(source) or not nodes.has(sink):
		return []
	var visited: Dictionary = {}
	var parent: Dictionary = {}
	for id in nodes:
		visited[id] = false
		parent[id] = null
	var q: Array = []
	q.push_back(source)
	visited[source] = true
	while q.size() > 0:
		var u: String = q.pop_front()
		var neighs: Array = adj.get(u, [])
		for v_item in neighs:
			var v: String = String(v_item)
			if not visited.get(v, false):
				var res_cap: float = float(capacity[u].get(v, 0.0))
				if res_cap + EPS >= need:
					parent[v] = u
					visited[v] = true
					if v == sink:
						var path: Array = []
						var cur: String = sink
						while cur != null:
							path.insert(0, cur)
							if cur == source:
								break
							cur = parent[cur]
						return path
					q.push_back(v)
	return []

# --------------------
# Operaciones sobre "files"
# --------------------
func add_file(file_id: String, user: String, code: String, weight: float, current_node: String) -> Dictionary:
	if files.has(file_id):
		return {"ok": false, "msg": "file_id already exists"}
	_ensure_node(current_node)
	var f: Dictionary = {
		"id": file_id,
		"user": user,
		"code": code,
		"weight": float(weight),
		"current_node": current_node,
		"status": "ok"
	}
	files[file_id] = f
	return {"ok": true, "file": f}

func delete_file(file_id: String) -> Dictionary:
	if not files.has(file_id):
		return {"ok": false, "msg": "file not found"}
	files.erase(file_id)
	return {"ok": true}

func shrink_file(file_id: String, new_weight: float) -> Dictionary:
	if not files.has(file_id):
		return {"ok": false, "msg": "file not found"}
	var f: Dictionary = files[file_id]
	if new_weight > float(f.get("weight", 0.0)):
		return {"ok": false, "msg": "new weight must be <= current weight"}
	f["weight"] = float(new_weight)
	files[file_id] = f
	return {"ok": true, "file": f}

func list_files() -> Array:
	var out: Array = []
	for k in files.keys():
		out.append(files[k])
	return out

# --------------------
# Timestamp helper
# --------------------
func get_timestamp() -> int:
	_ts_seq += 1
	return _ts_seq

# --------------------
# Antivirus / Validación
# --------------------
func validate_file(file_id: String) -> Dictionary:
	if not files.has(file_id):
		return {"ok": false, "msg": "file not found"}
	var f: Dictionary = files[file_id]
	var idstr: String = str(f.get("id", ""))
	var infected: bool = false
	if idstr.length() > 0:
		var last_char := idstr.substr(idstr.length() - 1, 1)
		if last_char == "A" or last_char == "a":
			infected = true
	f["status"] = ("infected" if infected else "ok")
	files[file_id] = f
	var entry: Dictionary = {
		"timestamp": get_timestamp(),
		"action": "validate",
		"file_id": file_id,
		"result": ("infected" if infected else "clean"),
		"note": ("id ends with 'A' => infected" if infected else "id clean")
	}
	validation_log.append(entry)
	return {"ok": true, "file": f, "infected": infected, "entry": entry}

func validate_all_files() -> Dictionary:
	var results: Dictionary = {}
	for k in files.keys():
		var fid: String = str(k)
		var res_entry: Dictionary = validate_file(fid)
		results[fid] = res_entry
	return {"ok": true, "results": results}

# --------------------
# Load files from JSON
# --------------------
func load_files_from_json(path: String = "res://files.json") -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "msg": "file not found", "path": path}
	var file_handle: FileAccess = FileAccess.open(path, FileAccess.ModeFlags.READ)
	if file_handle == null:
		return {"ok": false, "msg": "cannot open file", "path": path}
	var text: String = file_handle.get_as_text()
	var parsed_any: Variant = JSON.parse_string(text)

	var err_code: int = OK
	var root_variant: Variant = parsed_any

	if typeof(parsed_any) == TYPE_DICTIONARY:
		var parsed_dict: Dictionary = parsed_any
		if parsed_dict.has("error") and parsed_dict.has("result"):
			err_code = int(parsed_dict["error"])
			root_variant = parsed_dict["result"]
		else:
			root_variant = parsed_dict
			err_code = OK
	else:
		root_variant = parsed_any
		err_code = OK

	if err_code != OK:
		return {"ok": false, "msg": "json parse error", "err": err_code}

	if typeof(root_variant) != TYPE_ARRAY:
		return {"ok": false, "msg": "json root not array", "path": path}

	var arr: Array = root_variant
	var created: Array = []
	for entry in arr:
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var fid: String = str(entry.get("id", ""))
		if fid == "":
			continue
		var user: String = str(entry.get("user", ""))
		var code: String = str(entry.get("code", ""))
		var weight: float = float(entry.get("weight", 1.0))
		var node: String = str(entry.get("current_node", fid))
		if not files.has(fid):
			add_file(fid, user, code, weight, node)
			created.append(fid)
		else:
			var existing: Dictionary = files[fid]
			existing["user"] = user
			existing["code"] = code
			existing["weight"] = weight
			existing["current_node"] = node
			files[fid] = existing
		_ensure_node(node)
	return {"ok": true, "created": created, "path": path}

# --------------------
# Load graph from JSON
# --------------------
func load_graph_from_file(path: String = "res://graph.json") -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "msg": "file not found", "path": path}
	var file_handle: FileAccess = FileAccess.open(path, FileAccess.ModeFlags.READ)
	if file_handle == null:
		return {"ok": false, "msg": "cannot open file", "path": path}
	var text: String = file_handle.get_as_text()
	var parsed_any: Variant = JSON.parse_string(text)

	var err_code: int = OK
	var root_variant: Variant = parsed_any

	if typeof(parsed_any) == TYPE_DICTIONARY:
		var parsed_dict: Dictionary = parsed_any
		if parsed_dict.has("error") and parsed_dict.has("result"):
			err_code = int(parsed_dict["error"])
			root_variant = parsed_dict["result"]
		else:
			root_variant = parsed_dict
			err_code = OK
	else:
		root_variant = parsed_any
		err_code = OK

	if err_code != OK:
		return {"ok": false, "msg": "json parse error", "err": err_code}

	if typeof(root_variant) != TYPE_DICTIONARY:
		return {"ok": false, "msg": "graph json root must be a dictionary", "path": path}

	var root: Dictionary = root_variant
	if root.has("nodes") and typeof(root.get("nodes")) == TYPE_ARRAY:
		var nodes_arr: Array = root.get("nodes")
		for nid in nodes_arr:
			var nstr: String = str(nid)
			if nstr != "":
				_ensure_node(nstr)
	if not root.has("edges") or typeof(root.get("edges")) != TYPE_ARRAY:
		return {"ok": false, "msg": "edges must be an array", "path": path}
	var edges_arr: Array = root.get("edges")
	var created_edges: Array = []
	for e in edges_arr:
		if typeof(e) != TYPE_DICTIONARY:
			continue
		var u: String = str(e.get("u", ""))
		var v: String = str(e.get("v", ""))
		var cap: float = float(e.get("capacity", 1.0))
		if u == "" or v == "":
			continue
		_ensure_node(u)
		_ensure_node(v)
		add_edge(u, v, cap)
		created_edges.append({"u": u, "v": v, "capacity": cap})
	return {"ok": true, "edges_created": created_edges, "path": path}

# --------------------
# Send file (consume capacities)
# --------------------
func send_file(file_id: String, target_node: String) -> Dictionary:
	var timestamp: int = get_timestamp()
	if game_over:
		return {"ok": false, "result": "blocked", "msg": "Game over: no se permiten envíos"}

	if not files.has(file_id):
		return {"ok": false, "result": "error", "msg": "file not found"}

	var f: Dictionary = files[file_id]
	if String(f.get("status", "ok")) == "lost":
		return {"ok": false, "result": "error", "msg": "file is already lost"}

	if String(f.get("status", "ok")) == "infected":
		f["status"] = "lost"
		files[file_id] = f
		global_counter = max(0, global_counter - 1)
		var entry_inf: Dictionary = {
			"timestamp": timestamp,
			"file_id": file_id,
			"from_node": f.get("current_node", ""),
			"to_node": target_node,
			"path": [],
			"weight": float(f.get("weight", 0.0)),
			"result": "lost",
			"reason": "infected_on_send",
			"note": "file marked infected - sending causes immediate loss"
		}
		send_log.append(entry_inf)
		if global_counter <= 0:
			game_over = true
		return {"ok": false, "result": "lost", "msg": "file infected - sending causes immediate loss", "entry": entry_inf}

	var weight: float = float(f.get("weight", 0.0))
	var source: String = String(f.get("current_node", ""))
	_ensure_node(source)
	_ensure_node(target_node)

	var path: Array = _find_path_with_capacity(source, target_node, weight)
	if path.size() == 0:
		f["status"] = "lost"
		files[file_id] = f
		global_counter = max(0, global_counter - 1)
		var entry: Dictionary = {
			"timestamp": timestamp,
			"file_id": file_id,
			"from_node": source,
			"to_node": target_node,
			"path": [],
			"weight": weight,
			"result": "lost",
			"note": "no path with sufficient capacity"
		}
		send_log.append(entry)
		if global_counter <= 0:
			game_over = true
		return {"ok": false, "result": "lost", "msg": "no path with sufficient capacity", "entry": entry}

	for i in range(path.size() - 1):
		var u: String = path[i]
		var v: String = path[i + 1]
		if not capacity[u].has(v):
			capacity[u][v] = 0.0
		if not capacity[v].has(u):
			capacity[v][u] = 0.0
		capacity[u][v] = float(capacity[u].get(v, 0.0)) - weight
		if capacity[u][v] < 0.0 and capacity[u][v] > -EPS:
			capacity[u][v] = 0.0
		capacity[v][u] = float(capacity[v].get(u, 0.0)) + weight

	f["current_node"] = target_node
	f["status"] = "ok"
	files[file_id] = f

	var entry2: Dictionary = {
		"timestamp": timestamp,
		"file_id": file_id,
		"from_node": source,
		"to_node": target_node,
		"path": path,
		"weight": weight,
		"result": "success",
		"note": "sent and capacity consumed"
	}
	send_log.append(entry2)
	return {"ok": true, "result": "success", "path": path, "entry": entry2}

# --------------------
# Utilities
# --------------------
func get_counter() -> int:
	return global_counter

func set_counter(val: int) -> void:
	global_counter = val
	if global_counter <= 0:
		game_over = true

func get_log() -> Array:
	return send_log.duplicate(true)

func reset_game_state() -> void:
	global_counter = 5
	game_over = false
	send_log.clear()
	validation_log.clear()
	files.clear()
	nodes.clear()
	adj.clear()
	capacity.clear()
	initial_capacity.clear()
	edge_visuals.clear()
	last_flows_map.clear()
	last_max_flow = 0.0
	_ts_seq = 0

# --------------------
# Visualización textual simple del grafo
# --------------------
func show_graph() -> void:
	print("[GraphManager] Nodes:", nodes)
	print("[GraphManager] Adjacency lists:")
	for u_item in nodes:
		var ustr: String = String(u_item)
		print("  %s -> %s" % [ustr, adj.get(ustr, [])])
	print("[GraphManager] Edges (initial_capacity):")
	for u_key in initial_capacity.keys():
		var u: String = String(u_key)
		for v_key in initial_capacity[u].keys():
			var v: String = String(v_key)
			var cap: float = float(initial_capacity[u].get(v, 0.0))
			print("   %s -> %s : %s" % [u, v, str(cap)])
	print("[GraphManager] Current capacity (residual):")
	for u_key in capacity.keys():
		var u2: String = String(u_key)
		for v_key in capacity[u2].keys():
			var v2: String = String(v_key)
			var cap2: float = float(capacity[u2].get(v2, 0.0))
			print("   %s -> %s : %s" % [u2, v2, str(cap2)])
