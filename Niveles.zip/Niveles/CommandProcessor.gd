extends Node
class_name CommandProcessor

# CommandProcessor: legacy commands preserved (help, add_file / "add file", shrink)
# Añadido comando UI "list" / "packages" para ver los paquetes (files) desde la Terminal del juego.

@export var terminal_path: NodePath = NodePath("")

const LISTENER_METHOD: String = "on_terminal_command_received"
var terminal_ref: Node = null
var _registered: bool = false

func _ready() -> void:
	if terminal_path != NodePath("") and has_node(terminal_path):
		terminal_ref = get_node(terminal_path)
	else:
		terminal_ref = _find_node_by_name(get_tree().get_root(), "Terminal")

	if terminal_ref == null:
		print("[CommandProcessor] Terminal no encontrada en _ready(). Me registraré cuando Terminal esté disponible.")
		call_deferred("_deferred_try_register")
		return
	_register_to_terminal()

func _deferred_try_register() -> void:
	if terminal_ref == null:
		terminal_ref = _find_node_by_name(get_tree().get_root(), "Terminal")
	if terminal_ref == null:
		call_deferred("_deferred_try_register")
		return
	_register_to_terminal()

func _register_to_terminal() -> void:
	if terminal_ref == null:
		print("[CommandProcessor] No hay referencia a Terminal para registrar.")
		return

	if terminal_ref.has_method("add_command_listener"):
		var ok: bool = terminal_ref.add_command_listener(self, LISTENER_METHOD)
		if ok:
			_registered = true
			print("[CommandProcessor] Registrado correctamente como listener en Terminal.")
			if terminal_ref.has_method("append_output"):
				terminal_ref.append_output("[CmdProc] registrado para recibir comandos.")
		else:
			print("[CommandProcessor] Falló add_command_listener: el método no se registró.")
	elif terminal_ref.has_signal("terminal_command_entered"):
		terminal_ref.connect("terminal_command_entered", Callable(self, LISTENER_METHOD))
		_registered = true
		print("[CommandProcessor] Conectado directamente a la señal terminal_command_entered (fallback).")
		if terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] conectado a terminal_command_entered.")
	else:
		print("[CommandProcessor] Terminal no expone add_command_listener ni terminal_command_entered; no puedo registrarme.")

func _exit_tree() -> void:
	_unregister_from_terminal()

func _unregister_from_terminal() -> void:
	if terminal_ref == null:
		return
	if _registered:
		if terminal_ref.has_method("remove_command_listener"):
			terminal_ref.remove_command_listener(self, LISTENER_METHOD)
			print("[CommandProcessor] Desregistrado usando remove_command_listener.")
		elif terminal_ref.is_connected("terminal_command_entered", Callable(self, LISTENER_METHOD)):
			terminal_ref.disconnect("terminal_command_entered", Callable(self, LISTENER_METHOD))
			print("[CommandProcessor] Desconectado de terminal_command_entered (fallback).")
		_registered = false

# --------------------
# Entrada principal: llamada por Terminal
# --------------------
func on_terminal_command_received(cmd: String) -> void:
	if cmd == null:
		return
	var raw_parts: Array = str(cmd).strip_edges().split(" ")
	var parts: Array = []
	for p in raw_parts:
		var s: String = str(p).strip_edges()
		if s != "":
			parts.append(s)
	if parts.size() == 0:
		return

	# Soportar "add file" además de "add_file"
	var verb: String = parts[0].to_lower()
	if verb == "add" and parts.size() > 1 and parts[1].to_lower() == "file":
		parts.remove_at(1)
		parts[0] = "add_file"
		verb = "add_file"

	# Comandos legacy
	if verb == "help":
		_handle_help(parts)
		return
	if verb == "add_file":
		_handle_add_file(parts)
		return
	if verb == "shrink":
		_handle_shrink(parts)
		return

	# Comando UI: listar paquetes (files)
	if verb == "list" or verb == "packages":
		_handle_list_files(parts)
		return

	# No hacemos nada si el comando no corresponde a este processor
	return

# --------------------
# Handlers de comandos
# --------------------
func _handle_help(_parts: Array) -> void:
	var help_lines: Array = [
		"[CmdProc] comandos disponibles:",
		"  help                                  - muestra esta ayuda",
		"  add_file <id> <user> <code> <weight> <node>   - añade un archivo al GraphManager",
		"    (alternativa: \"add file <id> <user> <code> <weight> <node\")",
		"  shrink <file_id> <new_weight>         - reduce el peso de un archivo existente",
		"  list | packages                       - lista los paquetes (files) en el GraphManager",
		"",
		"[Nota] Los JSON se cargan por GraphManager al iniciar el programa."
	]
	if terminal_ref and terminal_ref.has_method("append_output"):
		for line in help_lines:
			terminal_ref.append_output(line)
	else:
		for line in help_lines:
			print(line)

func _handle_add_file(parts: Array) -> void:
	# Uso: add_file <id> <user> <code> <weight> <node>
	if parts.size() < 6:
		if terminal_ref and terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] uso: add_file <id> <user> <code> <weight> <node>")
		else:
			print("[CmdProc] uso: add_file <id> <user> <code> <weight> <node>")
		return
	var file_id: String = str(parts[1])
	var user: String = str(parts[2])
	var code: String = str(parts[3])
	var weight_val: float = 0.0
	var ok_parse: bool = true

	var wtxt: String = str(parts[4])
	if wtxt.is_valid_float():
		weight_val = float(wtxt)
	else:
		var w2: String = wtxt.replace(",", ".")
		if w2.is_valid_float():
			weight_val = float(w2)
		else:
			ok_parse = false

	if not ok_parse:
		if terminal_ref and terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] error: weight no es un número válido: " + str(parts[4]))
		else:
			print("[CmdProc] error: weight no es un número válido:", parts[4])
		return
	var node: String = str(parts[5])

	# Buscar GraphManager (nodo que exponga add_file)
	var gm: Node = _find_node_with_method("add_file")
	if gm == null:
		if terminal_ref and terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] GraphManager no encontrado (método add_file).")
		else:
			print("[CmdProc] GraphManager no encontrado (método add_file).")
		return

	var res: Dictionary = gm.call("add_file", file_id, user, code, weight_val, node)
	if terminal_ref and terminal_ref.has_method("append_output"):
		terminal_ref.append_output("[CmdProc] add_file -> " + str(res))
	else:
		print("[CmdProc] add_file ->", res)

func _handle_shrink(parts: Array) -> void:
	# Uso: shrink <file_id> <new_weight>
	if parts.size() < 3:
		if terminal_ref and terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] uso: shrink <file_id> <new_weight>")
		else:
			print("[CmdProc] uso: shrink <file_id> <new_weight>")
		return
	var file_id: String = str(parts[1])
	var new_weight_txt: String = str(parts[2])
	var new_weight: float = 0.0
	# parseo seguro
	if new_weight_txt.is_valid_float():
		new_weight = float(new_weight_txt)
	else:
		var nw2: String = new_weight_txt.replace(",", ".")
		if nw2.is_valid_float():
			new_weight = float(nw2)
		else:
			if terminal_ref and terminal_ref.has_method("append_output"):
				terminal_ref.append_output("[CmdProc] error: new_weight no es un número válido: " + new_weight_txt)
			else:
				print("[CmdProc] error: new_weight no es un número válido:", new_weight_txt)
			return

	var gm: Node = _find_node_with_method("shrink_file")
	if gm == null:
		if terminal_ref and terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] GraphManager no encontrado (método shrink_file).")
		else:
			print("[CmdProc] GraphManager no encontrado (método shrink_file).")
		return

	var result: Dictionary = gm.call("shrink_file", file_id, new_weight)
	if terminal_ref and terminal_ref.has_method("append_output"):
		terminal_ref.append_output("[CmdProc] shrink -> " + str(result))
	else:
		print("[CmdProc] shrink ->", result)

# --------------------
# Nuevo: listar paquetes (files) en la UI
# --------------------
func _handle_list_files(_parts: Array) -> void:
	var gm: Node = _find_node_with_method("list_files")
	if gm == null:
		if terminal_ref and terminal_ref.has_method("append_output"):
			terminal_ref.append_output("[CmdProc] GraphManager no encontrado (list_files).")
		else:
			print("[CmdProc] GraphManager no encontrado (list_files).")
		return
	var arr: Array = gm.call("list_files")
	# Mostrar detallado y legible
	if terminal_ref and terminal_ref.has_method("append_output"):
		if arr.size() == 0:
			terminal_ref.append_output("[CmdProc] No hay paquetes cargados.")
			return
		terminal_ref.append_output("[CmdProc] Paquetes cargados: (" + str(arr.size()) + ")")
		for item in arr:
			if typeof(item) == TYPE_DICTIONARY:
				var fid: String = str(item.get("id", ""))
				var user: String = str(item.get("user", ""))
				var code: String = str(item.get("code", ""))
				var weight: String = str(item.get("weight", ""))
				var node: String = str(item.get("current_node", ""))
				var status: String = str(item.get("status", ""))
				terminal_ref.append_output(" - " + fid + " | user:" + user + " | w:" + weight + " | node:" + node + " | " + status)
			else:
				terminal_ref.append_output(" - " + str(item))
	else:
		# Fallback consola editor
		print("[CmdProc] paquetes:", arr)

# --------------------
# Utilidades auxiliares
# --------------------
func _find_node_with_method(method_name: String) -> Node:
	var root: Node = get_tree().get_root()
	var stack: Array = [root]
	while stack.size() > 0:
		var n = stack.pop_back()
		if n is Node:
			if n.has_method(method_name):
				return n
			for c in n.get_children():
				stack.append(c)
	return null

func _find_node_by_name(root: Object, target_name: String) -> Node:
	if root == null:
		return null
	if root is Node:
		var maybe = root.get("name")
		if maybe != null and str(maybe) == target_name:
			return root
		for child in root.get_children():
			if child is Node:
				var found = _find_node_by_name(child, target_name)
				if found != null:
					return found
	return null
