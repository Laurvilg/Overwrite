extends Control
# Terminal.gd - Terminal robusto compatible Godot 3/4 (corregido)
# Espera tener en su escena (opcionalmente):
# VBoxContainer/Input  -> LineEdit (entrada)
# VBoxContainer/OutputScroll/Output -> TextEdit o RichTextLabel (salida)
signal terminal_command_entered(cmd: String)

var _listeners: Array = []   # lista de Dictionary { "target": Object, "method": String }
var _input_node: Node = null

func _ready() -> void:
	# Intentar rutas típicas primero
	if has_node("VBoxContainer/Input"):
		_input_node = $VBoxContainer/Input
	elif has_node("Input"):
		_input_node = $Input
	else:
		_input_node = _find_first_line_edit(self)
	if _input_node != null:
		print("[Terminal] Input encontrado:", _input_node.name, "class:", _input_node.get_class())
		# Conectar signals compatibles con Godot 3/4
		if _input_node.has_signal("text_entered"):
			_input_node.connect("text_entered", Callable(self, "_on_input_entered"))
			print("[Terminal] Conectado a text_entered")
		if _input_node.has_signal("text_submitted"):
			_input_node.connect("text_submitted", Callable(self, "_on_input_entered"))
			print("[Terminal] Conectado a text_submitted")
		# Conectar gui_input para debug / fallback
		if _input_node.has_signal("gui_input"):
			_input_node.connect("gui_input", Callable(self, "_on_input_gui"))
		# Dar foco de forma diferida (esperar a que todo esté listo)
		call_deferred("_deferred_grab_focus")
	else:
		print("[Terminal] No se encontró LineEdit (Input). Añade un LineEdit como hijo o ajusta rutas.")

func _find_first_line_edit(root: Node) -> Node:
	for child in root.get_children():
		if child.get_class() == "LineEdit":
			return child
		if child.get_child_count() > 0:
			var found: Node = _find_first_line_edit(child)
			if found != null:
				return found
	return null

func _deferred_grab_focus() -> void:
	if _input_node != null and _input_node.has_method("grab_focus"):
		_input_node.grab_focus()
		var has_focus_str: String = "n/a"
		if _input_node.has_method("has_focus"):
			has_focus_str = str(_input_node.has_focus())
		print("[Terminal] grab_focus() llamado en Input. has_focus:", has_focus_str)
	else:
		print("[Terminal] No se pudo grab_focus en Input.")

func _on_input_gui(event: InputEvent) -> void:
	# Registrar teclas para diagnosticar (y detectar Enter si las señales fallan)
	if event is InputEventKey:
		var ik := event as InputEventKey
		if ik.pressed and not ik.echo:
			# Obtener scancode de forma segura
			var sc: int = -1
			if ik.has_method("get_scancode"):
				sc = ik.get_scancode()
			elif "scancode" in ik:
				sc = ik.scancode
			print("[Terminal] gui_input key pressed: scancode=", sc, " unicode=", ik.unicode, " echo=", ik.echo)
			# detectar Enter usando unicode (10) o scancodes comunes (compatibilidad Godot3/Godot4)
			var is_enter: bool = false
			if ik.unicode == 10:
				is_enter = true
			# scancodes comunes: 16777221 (Enter), 16777296 (KP Enter) en muchas versiones
			if sc == 16777221 or sc == 16777296:
				is_enter = true
			if is_enter:
				# obtener texto actual y enviarlo
				var txt: String = ""
				if _input_node.has_method("get_text"):
					txt = _input_node.get_text()
				elif "text" in _input_node:
					txt = str(_input_node.text)
				if txt != "":
					print("[Terminal] gui_input detectó ENTER, emitiendo:", txt)
					_on_input_entered(txt)

func _on_input_entered(text: String) -> void:
	print("[Terminal] text_entered/text_submitted recibido:", str(text))
	emit_signal("terminal_command_entered", text)
	# Notificar listeners registrados
	for l in _listeners:
		if typeof(l) == TYPE_DICTIONARY and l.has("target") and l.has("method"):
			var tgt: Object = l["target"]
			var m: String = str(l["method"])
			if tgt != null and tgt.has_method(m):
				tgt.call(m, text)
	append_output("> " + str(text))
	# limpiar el input
	if _input_node != null:
		if _input_node.has_method("clear"):
			_input_node.clear()
		elif "text" in _input_node:
			_input_node.text = ""

# API para integrarse con CommandProcessor
func add_command_listener(target: Object, method_name: String) -> bool:
	if target == null or method_name == "":
		return false
	_listeners.append({"target": target, "method": method_name})
	return true

func remove_command_listener(target: Object, method_name: String) -> void:
	for i in range(_listeners.size() - 1, -1, -1):
		var l: Dictionary = _listeners[i]
		if l["target"] == target and l["method"] == method_name:
			_listeners.remove_at(i)

func append_output(text: String) -> void:
	# Intentar ruta típica que mostraste: VBoxContainer/OutputScroll/Output
	if has_node("VBoxContainer/OutputScroll/Output"):
		var out = $VBoxContainer/OutputScroll/Output
		if out is TextEdit:
			out.append_bbcode(str(text) + "\n")
			out.scroll_vertical = out.get_line_count()
		elif out is RichTextLabel:
			out.add_text(str(text) + "\n")
			out.scroll_to_line(out.get_line_count())
		else:
			if out.has_method("append_bbcode"):
				out.append_bbcode(str(text) + "\n")
			else:
				print(text)
	elif has_node("Output"):
		var out2 = $Output
		if out2 is TextEdit:
			out2.append_bbcode(str(text) + "\n")
		else:
			print(text)
	else:
		print(text)
